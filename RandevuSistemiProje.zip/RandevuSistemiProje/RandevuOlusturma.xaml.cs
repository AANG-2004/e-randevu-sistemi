using RandevuSistemiProje.Models;
using RandevuSistemiProje.Services;
using System.Collections.ObjectModel;

namespace RandevuSistemiProje;

public partial class RandevuOlusturma : ContentPage
{
	HastaService hastaService;
	IlService ilService;
    IlceService ilceService;
    HastaneService hastaneService;
    DoktorService doktorService;
    BolumService bolumService;
    RandevuService randevuService;

    List<Il> illerList;
    List<Ilce> ilcelerList;
    List<Hastane> hastaneList;
    List<Bolum> bolumList;
    List<Doktor> doktorList;

    List<string> illerAdList;
    List<string> ilcelerAdList;
    List<string> bolumAdList;
    List<string> doktorAdList;
    List<string> hastaneAdList;
    public RandevuOlusturma()
	{  
        InitializeComponent();
        hastaService = new HastaService();
        ilService = new IlService();
        ilceService = new IlceService(); 
        hastaneService = new HastaneService();
        bolumService = new BolumService();
        doktorService = new DoktorService();
        randevuService = new RandevuService();
      
        illerAdList = new List<string>();
        ilcelerAdList = new List<string>();
        bolumAdList = new List<string>();
        doktorAdList = new List<string>();
        hastaneAdList = new List<string>();
    }

    [Obsolete]
    private  void Kaydet_Clicked(object sender, EventArgs e)
    {

        if (!switchKontrol.IsToggled)
        {
            DisplayAlert("Uyar�", "L�tfen bilgileri tam doldurup butonu aktif edin", "Tamam");
            return;
        }
       

        addHasta();



    }

    [Obsolete]
    private void Iller_SelectedIndexChanged(object sender, EventArgs e)
    {
        updateIlceler();


    }

    [Obsolete]
    private void Iller_Focused(object sender, FocusEventArgs e)
    {
        if (illerList == null)
        {

   
            ilService.GetIller()
                .ContinueWith(t =>
                {
                    if (t.IsFaulted)
                    {
                        DisplayAlert("Uyar�", "�ller getirilemedi", "Tamam");
                        return;
                    }
                    illerList = t.Result;
                    Device.BeginInvokeOnMainThread(() =>
                    {
                        foreach (var il in illerList)
                        {
                            illerAdList.Add(il.Ad);
                        }
                        Picker_iller.ItemsSource = illerAdList;

                    });
                });

        }
    }
    [Obsolete]
    private void Picker_ilceler_Focused(object sender, FocusEventArgs e)
    {

      


    }

    [Obsolete]
    private void updateIlceler()
    {
        if (ilcelerList == null)
        {
            ilceService.GetIlceler()
                           .ContinueWith(t =>
                           {
                               if (t.IsFaulted)
                               {
                                   mesaj.Text = "ilceler getirilemedi";
                                   return;
                               }
                               ilcelerList = t.Result;
                               Device.BeginInvokeOnMainThread(() =>
                               {
                                   int ilId = 1;
                                   foreach (var i in illerList)
                                   {
                                       if (i.Ad.Equals(Picker_iller.SelectedItem))
                                       {
                                           ilId = i.Id;
                                       }
                                   }

                                   foreach (var ilce in ilcelerList)
                                   {
                                       if (ilce.IlId == ilId)
                                       {
                                           ilcelerAdList.Add(ilce.Ad);
                                       }

                                   }
                                   Picker_ilceler.ItemsSource = ilcelerAdList;

                               });
                           });
        }

        else
        {
            ilcelerAdList = new List<string>();
            int ilId = getIlId();

            foreach (var ilce in ilcelerList)
            {
                if (ilce.IlId == ilId)
                {
                    ilcelerAdList.Add(ilce.Ad);
                }

            }
            Picker_ilceler.ItemsSource = ilcelerAdList;
        }

    }

    private int getIlId()
    {
        var il = Picker_iller.SelectedItem;
        if(il != null)
        foreach (var item in illerList)
        {
            if (il.Equals(item.Ad))
            {
                return item.Id;
            }
        }
        return 0;
    }

    private int getIlceId()
    {
        var ilce = Picker_ilceler.SelectedItem;
        if(ilce != null)
        foreach(var item in ilcelerList)
        {
            if (ilce.Equals(item.Ad))
            {
                return item.Id;
            }
        }
        return 0;
    }

    private int getHastaneId()
    {
        var hastane = Picker_hastane.SelectedItem;
        if (hastane != null)
            foreach (var item in hastaneList)
            {
                if (hastane.Equals(item.Ad))
                {
                    return item.Id;
                }
            }
        return 0;
    }
    private int getDoktorId()
    {
        var doktor = Picker_doktor.SelectedItem;
        if(doktor != null)
            foreach(var item in doktorList)
            {
                if (doktor.Equals(item.Ad + " " + item.Soyad))
                {
                    return item.Id;
                }
            }
        return 0;
    }

    private DateTime getDateTime()
    {
        var date = randevuDate.Date;
        var time = randevuTime.Time;
        return date + time;
    }
    private int getBolumId()
    {
        var bolum = Picker_bolum.SelectedItem;
        if (bolum != null)
            foreach (var item in bolumList)
            {
                if (bolum.Equals(item.Ad))
                {
                    return item.Id;
                }
            }
        return 0;
    }
    [Obsolete]
    private void Picker_bolum_Focused(object sender, FocusEventArgs e)
    {
        if (bolumList == null)
        {
            bolumService.GetBolumler()
                           .ContinueWith(t =>
                           {
                               if (t.IsFaulted)
                               {
                                   mesaj.Text = "B�l�mler getirilemedi";
                                   return;
                               }
                               bolumList = t.Result;
                               Device.BeginInvokeOnMainThread(() =>
                               {
                                       foreach (var bolum in bolumList)
                                       {
                                               bolumAdList.Add(bolum.Ad);
                                       }
                                   Picker_bolum.ItemsSource = bolumAdList;

                               });
                           });
        }
    }

    [Obsolete]
    private void addHasta()
    {
        var hasta = new Hasta();

        hasta.Ad = HastaAdi.Text;
        hasta.Soyad = HastaSoyadi.Text;
        hasta.Tc = TcNo.Text;
        hasta.Telefon = TelNo.Text;

        hastaService.AddHasta(hasta)
                           .ContinueWith(t =>
                           {
                               if (t.IsFaulted)
                               {
                                   DisplayAlert("Uyar�", "Hasta eklenemedi", "Tamam");
                                   return;
                               }
                               var result = t.Result;
                               Device.BeginInvokeOnMainThread(() =>
                               {
                                   if (result > 0)
                                       addRandevu(result);
                                   else
                                   {
                                       DisplayAlert("Uyar�", "Hasta eklenemedi!", "Tamam");
                                   }
                               });
                           });
       }
    [Obsolete]
    private void addRandevu(int hastaId)
    {
        var randevu = new Randevu();

     
        var ilce = getIlceId();
        var il = getIlId();
        var bolum = getBolumId();
        var hastane = getHastaneId();
        var dateTime = getDateTime();
        var doktor = getDoktorId();
        var kontrol = switchKontrol.IsToggled;
        randevu.Tarih = dateTime;
        randevu.DoktorId = doktor;
        randevu.HastaId = hastaId;
        randevu.HastaneId = hastane;
        

        randevuService.AddRandevu(randevu)
                           .ContinueWith(t =>
                           {
                               if (t.IsFaulted)
                               {
                                   DisplayAlert("Uyar�", "Randevu olu�tururulamad�", "Tamam");
                                   return;
                               }
                               var result = t.Result;
                               Device.BeginInvokeOnMainThread(() =>
                               {
                                   DisplayAlert("Uyar�", "Randevu olu�turuldu", "Tamam");


                                   Navigation.PushAsync(new MainPage());
                               });
                           });
    }

    [Obsolete]
    private void updateHastaneler(int ilceId)
    {
        if (hastaneList == null)
        {
            hastaneService.GetHastaneler()
                           .ContinueWith(t =>
                           {
                               if (t.IsFaulted)
                               {
                                   mesaj.Text = "hastaneler getirilemedi";
                                   return;
                               }
                               hastaneList = t.Result;
                               Device.BeginInvokeOnMainThread(() =>
                               {
     

                                  if(ilceId < 1)
                                   foreach (var hastane in hastaneList)
                                   {
                                  
                                       hastaneAdList.Add(hastane.Ad);
                                    

                                   }
                                   else
                                   {
                                       foreach (var hastane in hastaneList)
                                       {
                                           if(ilceId == hastane.IlceId)
                                             hastaneAdList.Add(hastane.Ad);


                                       }
                                   }

                                   Picker_hastane.ItemsSource=hastaneAdList;

                               });
                           });
        }

        else
        {
            hastaneAdList = new List<string>();

            foreach (var hastane in hastaneList)
            {
                if (hastane.IlceId == ilceId)
                {
                    hastaneAdList.Add(hastane.Ad);
                }

            }
            Picker_hastane.ItemsSource = hastaneAdList;
        }

    }
    [Obsolete]
    private void updateDoktorlar(int hastaneId, int bolumId)
    {
        if (doktorList == null)
        {
            doktorService.GetDoktorlar()
                           .ContinueWith(t =>
                           {
                               if (t.IsFaulted)
                               {
                                   mesaj.Text = "doktorlar getirilemedi";
                                   return;
                               }
                               doktorList = t.Result;
                               Device.BeginInvokeOnMainThread(() =>
                               {


                                   if (hastaneId < 1 || bolumId < 1)
                                       foreach (var doktor in doktorList)
                                       {

                                           doktorAdList.Add(doktor.Ad+" "+doktor.Soyad);


                                       }
                                   else
                                   {
                                       foreach (var doktor in doktorList)
                                       {
                                           if (hastaneId == doktor.HastaneId && bolumId == doktor.BolumId)
                                               doktorAdList.Add(doktor.Ad+" "+doktor.Soyad);


                                       }
                                   }

                                   Picker_doktor.ItemsSource = doktorAdList;

                               });
                           });
        }

        else
        {
            doktorAdList = new List<string>();


            if (hastaneId < 1 || bolumId < 1)
                foreach (var doktor in doktorList)
                {

                    doktorAdList.Add(doktor.Ad +" "+ doktor.Soyad);


                }
            else
            {
                foreach (var doktor in doktorList)
                {
                    if (hastaneId == doktor.HastaneId && bolumId == doktor.BolumId)
                        doktorAdList.Add(doktor.Ad + " " + doktor.Soyad);


                }
            }

            Picker_doktor.ItemsSource = doktorAdList;
        }

    }


    [Obsolete]
    private void Picker_hastane_Focused(object sender, FocusEventArgs e)
    {
    
    }

    [Obsolete]
    private void Picker_hastane_SelectedIndexChanged(object sender, EventArgs e)
    {
      
    }

    [Obsolete]
    private void Picker_ilceler_SelectedIndexChanged(object sender, EventArgs e)
    {
        int id = getIlceId();
        updateHastaneler(id);
    }

    [Obsolete]
    private void Picker_bolum_SelectedIndexChanged(object sender, EventArgs e)
    {
        updateDoktorlar(getHastaneId(), getBolumId());
    }
}

