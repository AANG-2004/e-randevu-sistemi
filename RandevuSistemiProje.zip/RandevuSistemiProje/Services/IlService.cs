﻿using RandevuSistemiProje.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace RandevuSistemiProje.Services
{
    internal class IlService
    {
        string address = "http://localhost:5097/api/Il/";

        HttpClient client;

        public IlService()
        {
            client = new HttpClient();
        }

        public async Task<List<Il>> GetIller()
        {
            var cevap = await client.GetAsync(address);

            if (cevap.IsSuccessStatusCode)
            {
                string gelenVeri = await cevap.Content.ReadAsStringAsync();
                var iller = JsonSerializer.Deserialize<List<Il>>(gelenVeri, new JsonSerializerOptions
                {
                    PropertyNamingPolicy = JsonNamingPolicy.CamelCase
                });

                return iller;

            }

            return new List<Il>();
        }

        public async Task<Il> GetIl(int id)
        {
            var cevap = await client.GetAsync(address + id.ToString());

            if (cevap.IsSuccessStatusCode)
            {
                string gelenVeri = await cevap.Content.ReadAsStringAsync();

                var il = JsonSerializer.Deserialize<Il>(gelenVeri, new JsonSerializerOptions
                {
                    PropertyNamingPolicy = JsonNamingPolicy.CamelCase
                });

                return il;

            }

            return new Il();
        }

    }
}
