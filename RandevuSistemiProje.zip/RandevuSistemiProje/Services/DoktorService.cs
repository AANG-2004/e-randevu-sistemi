using RandevuSistemiProje.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace RandevuSistemiProje.Services
{
    internal class DoktorService
    {
        string address = "http://localhost:5097/api/Doktor/";

        HttpClient client;

        public DoktorService()
        {
            client = new HttpClient();
        }

        public async Task<List<Doktor>> GetDoktorlar()
        {
            var cevap = await client.GetAsync(address);

            if (cevap.IsSuccessStatusCode)
            {
                string gelenVeri = await cevap.Content.ReadAsStringAsync();
                var Doktorlar = JsonSerializer.Deserialize<List<Doktor>>(gelenVeri, new JsonSerializerOptions
                {
                    PropertyNamingPolicy = JsonNamingPolicy.CamelCase
                });

                return Doktorlar;

            }

            return new List<Doktor>();
        }
        public async Task<Doktor> GetDoktor(int id)
        {
            var cevap = await client.GetAsync(address + id.ToString());

            if (cevap.IsSuccessStatusCode)
            {
                string gelenVeri = await cevap.Content.ReadAsStringAsync();

                var doktor = JsonSerializer.Deserialize<Doktor>(gelenVeri, new JsonSerializerOptions
                {
                    PropertyNamingPolicy = JsonNamingPolicy.CamelCase
                });

                return doktor;

            }

            return new Doktor();
        }

    }
}
