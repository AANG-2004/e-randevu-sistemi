﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.Unicode;
using System.Threading.Tasks;
using RandevuSistemiProje.Models;

namespace RandevuSistemiProje.Services
{
    internal class RandevuService
    {
        string address = "http://localhost:5097/api/Randevu/";

        HttpClient client;

        public RandevuService()
        {
            client = new HttpClient();
        }

        public async Task<Randevu> GetRandevu(int id)
        {
            var cevap = await client.GetAsync(address + id.ToString());

            if (cevap.IsSuccessStatusCode)
            {
                string gelenVeri = await cevap.Content.ReadAsStringAsync();

                var randevu = JsonSerializer.Deserialize<Randevu>(gelenVeri, new JsonSerializerOptions
                {
                    PropertyNamingPolicy = JsonNamingPolicy.CamelCase
                });

                return randevu;

            }

            return new Randevu();
        }
        public async Task<Boolean> AddRandevu(Randevu randevu)
        {
            StringContent randevuContent = new(JsonSerializer.Serialize(randevu), Encoding.UTF8, "application/json");

            var cevap = await client.PostAsync(address, randevuContent);

            if (cevap.IsSuccessStatusCode)
            {

                return true;

            }
            return false;
        }




    }
}