using RandevuSistemiProje.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace RandevuSistemiProje.Services
{
    internal class BolumService
    {
        string address = "http://localhost:5097/api/Bolum/";

        HttpClient client;

        public BolumService()
        {
            client = new HttpClient();
        }

        public async Task<List<Bolum>> GetBolumler()
        {
            var cevap = await client.GetAsync(address);

            if (cevap.IsSuccessStatusCode)
            {
                string gelenVeri = await cevap.Content.ReadAsStringAsync();
                var Bolumler = JsonSerializer.Deserialize<List<Bolum>>(gelenVeri, new JsonSerializerOptions
                {
                    PropertyNamingPolicy = JsonNamingPolicy.CamelCase
                });

                return Bolumler;

            }

            return new List<Bolum>();
        }
        public async Task<Bolum> GetBolum(int id)
        {
            var cevap = await client.GetAsync(address + id.ToString());

            if (cevap.IsSuccessStatusCode)
            {
                string gelenVeri = await cevap.Content.ReadAsStringAsync();

                var bolum = JsonSerializer.Deserialize<Bolum>(gelenVeri, new JsonSerializerOptions
                {
                    PropertyNamingPolicy = JsonNamingPolicy.CamelCase
                });

                return bolum;

            }

            return new Bolum();
        }

    }
}
