﻿using RandevuSistemiProje.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace RandevuSistemiProje.Services
{
    internal class IlceService
    {
        string address = "http://localhost:5097/api/Ilce/";

        HttpClient client;

        public IlceService()
        {
            client = new HttpClient();
        }

        public async Task<List<Ilce>> GetIlceler()
        {
            var cevap = await client.GetAsync(address);

            if (cevap.IsSuccessStatusCode)
            {
                string gelenVeri = await cevap.Content.ReadAsStringAsync();
                var ilceler = JsonSerializer.Deserialize<List<Ilce>>(gelenVeri, new JsonSerializerOptions
                {
                    PropertyNamingPolicy = JsonNamingPolicy.CamelCase
                });

                return ilceler;

            }

            return new List<Ilce>();
        }

        public async Task<Ilce> GetIlce(int id)
        {
            var cevap = await client.GetAsync(address + id.ToString());

            if (cevap.IsSuccessStatusCode)
            {
                string gelenVeri = await cevap.Content.ReadAsStringAsync();

                var ilce = JsonSerializer.Deserialize<Ilce>(gelenVeri, new JsonSerializerOptions
                {
                    PropertyNamingPolicy = JsonNamingPolicy.CamelCase
                });

                return ilce;

            }

            return new Ilce();
        }
    }
}
