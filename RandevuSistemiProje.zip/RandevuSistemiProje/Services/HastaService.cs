﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.Unicode;
using System.Threading.Tasks;
using RandevuSistemiProje.Models;

namespace RandevuSistemiProje.Services
{
    internal class HastaService
    {
        string address = "http://localhost:5097/api/Hasta/";

        HttpClient client;

        public HastaService()
        {
            client = new HttpClient();
        }

        public async Task<Hasta> GetHasta(string tc)
        {
            var cevap = await client.GetAsync(address+tc);

            if (cevap.IsSuccessStatusCode)
            {
                string gelenVeri = await cevap.Content.ReadAsStringAsync();
     
                var hasta = JsonSerializer.Deserialize<Hasta>(gelenVeri, new JsonSerializerOptions
                {
                    PropertyNamingPolicy = JsonNamingPolicy.CamelCase
                });

                return hasta;

            }

            return new Hasta();
        }
        public async Task<int> AddHasta(Hasta hasta)
        {
            StringContent hastaContent = new(JsonSerializer.Serialize(hasta), Encoding.UTF8, "application/json");

            var cevap = await client.PostAsync(address, hastaContent);
        
            if (cevap.IsSuccessStatusCode)
            {
                string gelenVeri = await cevap.Content.ReadAsStringAsync();

                var eklenen = JsonSerializer.Deserialize<Hasta>(gelenVeri, new JsonSerializerOptions
                {
                    PropertyNamingPolicy = JsonNamingPolicy.CamelCase
                });

                return eklenen.Id;

            }
            return 0;
        }




    }
}
