﻿using RandevuSistemiProje;
using RandevuSistemiProje;

namespace RandevuSistemiProje
{
    public partial class MainPage : ContentPage
    {
        int count = 0;

        public MainPage()
        {
            InitializeComponent();
        }

        private async void RandevuSorgulama_Clicked(System.Object sender, System.EventArgs e)
        {
            Navigation.PushAsync(new RandevuSorgulama());
        }

        private void RandevuOlustur_Clicked(System.Object sender, System.EventArgs e)
        {
            Navigation.PushAsync(new RandevuOlusturma());
        }

    }

}
