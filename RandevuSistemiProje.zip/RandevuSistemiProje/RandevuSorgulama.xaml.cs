
using RandevuSistemiProje.Models;
using RandevuSistemiProje.Services;

namespace RandevuSistemiProje;

public partial class RandevuSorgulama : ContentPage
{

	RandevuService randevuService;
    HastaService hastaService;
    HastaneService hastaneService;
    IlService ilService;
    IlceService ilceService;
    BolumService bolumService;
    DoktorService doktorService;

    [Obsolete]
    public RandevuSorgulama()
	{
		randevuService = new RandevuService();
        hastaService = new HastaService();
        ilService = new IlService();   
        ilceService = new IlceService();
        doktorService = new DoktorService();
        hastaneService = new HastaneService();
        bolumService = new BolumService();

        InitializeComponent();
    }

    private void Sorgula_Clicked(object sender, EventArgs e)
    {
        getHasta(TcNo.Text);
    }

    [Obsolete]
    private void getHasta(string tc)
    {
        hastaService.GetHasta(tc)
                           .ContinueWith(t =>
                           {
                               if (t.IsFaulted)
                               {
                                   DisplayAlert("Uyar�", "Hasta getirilemedi", "Tamam");
                                   return;
                               }
                               Hasta hasta = t.Result;
                               Device.BeginInvokeOnMainThread(() =>
                               {
                                   labelAd.Text = hasta.Ad;
                                   labelSoyad.Text = hasta.Soyad;
                              
                                   getRandevu(hasta.Id);

                               });
                           });
    }

    [Obsolete]
    private void getHastane(int id)
    {
        hastaneService.GetHastane(id)
            .ContinueWith(t =>
            {
                if (t.IsFaulted)
                {

                    return;
                }
                Hastane hastane = t.Result;
                Device.BeginInvokeOnMainThread(() =>
                {
                    labelHastane.Text = hastane.Ad;
                    getIl(hastane.IlId);
                    getIlce(hastane.IlceId);

                });
            });
    }

    [Obsolete]
    private void getBolum(int id)
    {
        bolumService.GetBolum(id)
   .ContinueWith(t => {
       if (t.IsFaulted)
       {

           return;
       }
       Bolum bolum = t.Result;
       Device.BeginInvokeOnMainThread(() =>
       {
           if (bolum != null)
               labelBolum.Text = bolum.Ad;
           else
               labelBolum.Text = "b�l�m bulunamad�";

       });
   });
    }

    [Obsolete]
    private void getDoktor(int id)
    {
        doktorService.GetDoktor(id)
    .ContinueWith(t =>
    {
        if (t.IsFaulted)
        {

            return;
        }
        Doktor doktor = t.Result;
        Device.BeginInvokeOnMainThread(() =>
        {
            getBolum(doktor.BolumId);
            labelDoktor.Text = doktor.Ad + doktor.Soyad;
           

        });
    });
    }

    [Obsolete]
    private void getIl(int id)
    {
        ilService.GetIl(id)
     .ContinueWith(t =>
     {
         if (t.IsFaulted)
         {

             return;
         }
         Il il = t.Result;
         Device.BeginInvokeOnMainThread(() =>
         {
            label_Il.Text = il.Ad;

         });
     });
    }

    [Obsolete]
    private void getIlce(int id)
    {
        ilceService.GetIlce(id)
 .ContinueWith(t =>
 {
     if (t.IsFaulted)
     {

         return;
     }
     Ilce ilce = t.Result;
     Device.BeginInvokeOnMainThread(() =>
     {
        label_Ilce.Text = ilce.Ad;

     });
 });
    }

    [Obsolete]
    private void getRandevu(int hastaId)
    {
        randevuService.GetRandevu(hastaId)
            
                          .ContinueWith(t =>
                          {
                              
                              if (t.IsFaulted)
                              {

                                  return;
                              }
                              Randevu randevu = t.Result;
                              Device.BeginInvokeOnMainThread(() =>
                              {
                                  getHastane(randevu.HastaneId);
                                  getDoktor(randevu.DoktorId);

                                  label_Tarih.Text = randevu.Tarih.ToString();


                              });
                          });
    }
    
}