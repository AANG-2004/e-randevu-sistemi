﻿namespace RandevuSistemiProje.Models
{
    public class Ilce
    {
        public int Id { get; set; }

        public string Ad {  get; set; }

        public int IlId { get; set; }
    }
}
