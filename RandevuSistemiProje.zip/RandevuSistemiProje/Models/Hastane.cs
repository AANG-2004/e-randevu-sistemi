﻿namespace RandevuSistemiProje.Models
{
    public class Hastane
    {
        public int Id { get; set; }

        public string Ad {  get; set; }
        public int IlId { get; set; }

        public int IlceId { get; set; }



    }
}
