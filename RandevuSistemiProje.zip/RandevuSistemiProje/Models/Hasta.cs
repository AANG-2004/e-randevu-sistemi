﻿namespace RandevuSistemiProje.Models
{
    public class Hasta
    {
        public string Ad { get; set; }
        public string Soyad { get; set; }
        public int Id { get; set; }
        public string Tc { get; set; }
        public string Telefon { get; set; }
    }
}
