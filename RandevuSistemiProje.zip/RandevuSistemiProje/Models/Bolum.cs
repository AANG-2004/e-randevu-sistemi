﻿namespace RandevuSistemiProje.Models
{
    public class Bolum
    {
        public int Id { get; set; }
        public string Ad { get; set; }


    }
}
