﻿namespace RandevuSistemiProje.Models
{
    public class Doktor
    {
        public string Ad { get; set; }
        public string Soyad { get; set; }
        public int Id { get; set; }

        public int BolumId { get; set; }
        public int HastaneId { get; set; }


    }
}
