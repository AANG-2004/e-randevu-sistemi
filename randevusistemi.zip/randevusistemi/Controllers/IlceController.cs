﻿using AracKiralamaAPI.EFCore;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using randevusistemi.Models;
using System.Net;

namespace randevusistemi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class IlceController : ControllerBase
    {

        private RandevuSistemiContext context;


        public IlceController()
        {
            context = new RandevuSistemiContext();
        }



        [HttpGet]
        public List<Ilce> GetIlcelarList()
        {
            return context.Ilceler.ToList();
        }

        [HttpGet("{id}")]
        public Ilce GetIlce(int id)
        {
            var ilce = context.Ilceler.Where(x => x.Id == id).FirstOrDefault();
            return ilce;
        }

        [HttpPost]
        public HttpStatusCode AddIlce(Ilce ilce)
        {
            context.Ilceler.Add(ilce);
            context.SaveChanges();
            return HttpStatusCode.OK;
        }
    }
}
