﻿using AracKiralamaAPI.EFCore;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using randevusistemi.Models;
using System.Net;

namespace randevusistemi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BolumController : ControllerBase
    {

        private RandevuSistemiContext context;


        public BolumController()
        {
            context = new RandevuSistemiContext();
        }



        [HttpGet]
        public List<Bolum> GetBolumlerList()
        {
            return context.Bolumler.ToList();
        }

        [HttpGet("{id}")]
        public Bolum GetBolum(int id)
        {
            var bolum = context.Bolumler.Where(x => x.Id == id).FirstOrDefault();
            return bolum;
        }

        [HttpPost]
        public HttpStatusCode AddBolum(Bolum bolum)
        {
            context.Bolumler.Add(bolum);
            context.SaveChanges();
            return HttpStatusCode.OK;
        }
    }
}
