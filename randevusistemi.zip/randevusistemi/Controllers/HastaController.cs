﻿using AracKiralamaAPI.EFCore;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using randevusistemi.Models;
using System.Linq;
using System.Net;

namespace randevusistemi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HastaController : ControllerBase
    {

        private RandevuSistemiContext context;

 
        public HastaController() {
            context = new RandevuSistemiContext();
        }



        [HttpGet]
        public List<Hasta> GetHastalarList()
        {
            return context.Hastalar.ToList();
        }

        [HttpGet("{tc}")]
        public Hasta GetHasta(string tc)
        {
            var hasta = context.Hastalar.Where(x => x.Tc.Equals(tc)).FirstOrDefault();
            return hasta;
        }

        [HttpPost]
        public Hasta AddHasta(Hasta hasta)
        {
            context.Hastalar.Add(hasta);
            context.SaveChanges();

            return hasta ;
        }
    }
}
