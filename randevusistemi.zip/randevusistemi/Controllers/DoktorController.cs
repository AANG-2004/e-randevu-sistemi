﻿using AracKiralamaAPI.EFCore;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using randevusistemi.Models;
using System.Net;

namespace randevusistemi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DoktorController : ControllerBase
    {

        private RandevuSistemiContext context;


        public DoktorController()
        {
            context = new RandevuSistemiContext();
        }



        [HttpGet]
        public List<Doktor> GetDoktorlarList()
        {
            return context.Doktorlar.ToList();
        }

        [HttpGet("{id}")]
        public Doktor GetDoktor(int id)
        {
            var doktor = context.Doktorlar.Where(x => x.Id == id).FirstOrDefault();
            return doktor;
        }

        [HttpPost]
        public HttpStatusCode AddDoktor(Doktor doktor)
        {
            context.Doktorlar.Add(doktor);
            context.SaveChanges();
            return HttpStatusCode.OK;
        }
    }
}
