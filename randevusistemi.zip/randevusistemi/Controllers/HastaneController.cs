﻿using AracKiralamaAPI.EFCore;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using randevusistemi.Models;
using System.Net;

namespace randevusistemi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HastaneController : ControllerBase
    {

        private RandevuSistemiContext context;


        public HastaneController()
        {
            context = new RandevuSistemiContext();
        }



        [HttpGet]
        public List<Hastane> GetHastanelerList()
        {
            return context.Hastaneler.ToList();
        }

        [HttpGet("{id}")]
        public Hastane GetHastane(int id)
        {
            var hastane = context.Hastaneler.Where(x => x.Id == id).FirstOrDefault();
            return hastane;
        }

        [HttpPost]
        public HttpStatusCode AddHastane(Hastane hastane)
        {
            context.Hastaneler.Add(hastane);
            context.SaveChanges();
            return HttpStatusCode.OK;
        }
    }
}
