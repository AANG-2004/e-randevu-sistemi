﻿using AracKiralamaAPI.EFCore;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using randevusistemi.Models;
using System.Net;

namespace randevusistemi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RandevuController : ControllerBase
    {

        private RandevuSistemiContext context;


        public RandevuController()
        {
            context = new RandevuSistemiContext();
        }



        [HttpGet]
        public List<Randevu> GetRandevularList()
        {
            return context.Randevular.ToList();
        }

        [HttpGet("{hastaId}")]
        public Randevu GetRandevu(int hastaId)
        {
            var randevu = context.Randevular.Where(x => x.HastaId == hastaId).FirstOrDefault();
            return randevu;
        }

        [HttpPost]
        public HttpStatusCode AddRandevu(Randevu randevu)
        {
            context.Randevular.Add(randevu);
            context.SaveChanges();
            return HttpStatusCode.OK;
        }

 
    }
}
