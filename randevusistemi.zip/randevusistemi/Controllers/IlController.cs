﻿using AracKiralamaAPI.EFCore;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using randevusistemi.Models;
using System.Net;

namespace randevusistemi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class IlController : ControllerBase
    {

        private RandevuSistemiContext context;


        public IlController()
        {
            context = new RandevuSistemiContext();
        }



        [HttpGet]
        public List<Il> GetIllerList()
        {
            return context.Iller.ToList();
        }

        [HttpGet("{id}")]
        public Il GetIl(int id)
        {
            var ıl = context.Iller.Where(x => x.Id == id).FirstOrDefault();
            return ıl;
        }

        [HttpPost]
        public HttpStatusCode AddIl(Il ıl)
        {
            context.Iller.Add(ıl);
            context.SaveChanges();
            return HttpStatusCode.OK;
        }
    }
}
