﻿using randevusistemi.Models;
using Microsoft.EntityFrameworkCore;

namespace AracKiralamaAPI.EFCore
{
    public class RandevuSistemiContext : DbContext
    {
        public DbSet<Hasta> Hastalar { get; set; }
        public DbSet<Doktor> Doktorlar { get; set; }
        public DbSet<Bolum> Bolumler { get; set; }
        public DbSet<Hastane> Hastaneler { get; set; }
        public DbSet<Il> Iller { get; set; }
        public DbSet<Ilce> Ilceler { get; set; }

        public DbSet<Randevu> Randevular { get; set; }






        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=DESKTOP-QJT6CHE\\SQLEXPRESS;Initial Catalog=randevusistemi;User ID=randevu;Password=randevu123;TrustServerCertificate=True;");
            base.OnConfiguring(optionsBuilder);
        }
    }
}

