﻿namespace randevusistemi.Models
{
    public class Il
    {
        public string Ad { get; set; }
        public int Id { get; set; }
        
    }
}
